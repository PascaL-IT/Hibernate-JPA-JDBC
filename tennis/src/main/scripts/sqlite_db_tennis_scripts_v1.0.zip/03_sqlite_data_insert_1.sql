﻿INSERT INTO TOURNOI (NOM, CODE) VALUES ("Australian Open","AO");
INSERT INTO TOURNOI (NOM, CODE) VALUES ("Roland Garros","RG");
INSERT INTO TOURNOI (NOM, CODE) VALUES ("Wimbledon","WI");
INSERT INTO TOURNOI (NOM, CODE) VALUES ("US Open","US");

--- commit;

-- DELETE FROM TOURNOI;
-- SELECT * FROM TOURNOI;

-- select * from sqlite_sequence where name='TOURNOI';
-- UPDATE sqlite_sequence SET SEQ=0 WHERE NAME='TOURNOI';